## What changed

[Describe the user-visible change and why it is needed.]

## How it was verified

- [ ] Tests added or updated
- [ ] Existing tests pass
- [ ] Documentation updated
- [ ] No secrets, generated credentials, or personal data included

## Screenshots or logs

[Include only sanitized evidence when useful.]

## Related issue

Closes #[issue]


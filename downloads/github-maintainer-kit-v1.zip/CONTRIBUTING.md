# Contributing

Thank you for contributing to [Project].

1. Search existing issues before opening a new one.
2. For non-trivial changes, open an issue before writing code.
3. Create a focused branch and keep unrelated changes separate.
4. Add or update tests and documentation.
5. Open a pull request using the repository template.

## Development

```bash
[install-command]
[test-command]
[lint-command]
```

By contributing, you confirm that you have the right to submit the work under this project's license.


# GitHub 项目维护模板包

适合希望快速规范 Issue、Pull Request、贡献与安全报告流程的公开仓库。

## 文件

- `.github/ISSUE_TEMPLATE/bug_report.yml`
- `.github/ISSUE_TEMPLATE/feature_request.yml`
- `.github/ISSUE_TEMPLATE/docs_request.yml`
- `.github/pull_request_template.md`
- `CONTRIBUTING.md`
- `SECURITY.md`

复制到仓库根目录后，替换所有 `[占位符]` 并提交。发布前务必确认联系方式和支持版本。


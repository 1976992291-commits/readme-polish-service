# Security Policy

## Supported versions

| Version | Supported |
|---|---|
| [current] | ✅ |
| [older] | ❌ |

## Reporting a vulnerability

Do not open a public issue for an unpatched vulnerability. Report it through [GitHub private vulnerability reporting / security email]. Include affected versions, impact, reproduction steps, and any known mitigation. We aim to acknowledge reports within [time] and will coordinate disclosure after a fix is available.


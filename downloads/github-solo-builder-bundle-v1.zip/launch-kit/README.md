# 独立项目上线检查包

面向独立开发者的轻量发布流程：从仓库卫生、事实核对、安全检查到发布文案，一次走完。

## 包含

- `launch-checklist.md`：上线前总检查
- `security-basics.md`：最低安全基线
- `release-template.md`：Release Notes 模板
- `launch-copy.md`：中英文发布文案模板


# 发布文案模板

## 中文短版

今天发布了 **[产品名]**：帮助[目标用户]用[更少时间/更低成本]完成[任务]。现在支持[3 个核心能力]。体验：[链接]。欢迎告诉我最卡的一步。

## English short version

Today I launched **[Product]**, a [category] for [audience] who need to [outcome]. It supports [three concrete capabilities]. Try it: [link]. I would love to hear where the workflow still feels slow.

## GitHub Release 摘要

本次版本重点解决[问题]，新增[功能]，并修复[问题]。升级前请阅读[迁移说明]；已知限制见[链接]。


# [Product] v[Version]

## Highlights

- [User-visible improvement and outcome]
- [Second improvement]

## Upgrade

```bash
[upgrade-command]
```

## Breaking changes

- [Change, affected users, and migration step]

## Fixed

- [Fix] (#[issue])

## Known issues

- [Issue and workaround]

**Full diff:** `[previous]...[current]`


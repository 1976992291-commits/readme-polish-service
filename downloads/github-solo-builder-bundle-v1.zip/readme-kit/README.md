# GitHub README 快速上线包（中英双语）

一套可复制、替换占位符后直接使用的 README 模板，适合独立开发者、小团队与开源项目。

## 包含内容

- `templates/ai-project-bilingual.md`：AI / Agent 项目中英双语模板
- `templates/cli-tool-bilingual.md`：命令行工具中英双语模板
- `templates/library-bilingual.md`：代码库 / SDK 中英双语模板
- `templates/saas-bilingual.md`：SaaS / Web 应用中英双语模板
- `templates/profile-readme.md`：GitHub 个人主页模板
- `checklists/readme-release-checklist.md`：发布前检查清单
- `prompts/readme-prompts.md`：可直接交给 AI 的 README 提示词
- `snippets/common-sections.md`：徽章、安装、FAQ、安全声明等常用片段

## 使用方法

1. 根据项目类型选择一个模板。
2. 全局替换 `[项目名]`、`[仓库地址]` 等方括号占位符。
3. 删除不适用的章节。
4. 按检查清单逐项确认命令、链接和截图。
5. 提交到仓库根目录并命名为 `README.md`。

## 许可

购买者可将模板用于自己或客户的任意数量项目，并可修改后随项目公开发布；不得原样或改名转售、分发本模板包。详见 `LICENSE_TERMS.md`。


# 常用 README 片段

## 状态徽章

```md
![CI](https://github.com/[owner]/[repo]/actions/workflows/[workflow].yml/badge.svg)
![License](https://img.shields.io/github/license/[owner]/[repo])
![Release](https://img.shields.io/github/v/release/[owner]/[repo])
```

## 安全声明

```md
## Security

Please do not disclose unpatched vulnerabilities in public issues. Follow [SECURITY.md](SECURITY.md) to report them privately.
```

## 支持范围

```md
## Support

Bug reports are welcome in GitHub Issues. Usage questions are handled on a best-effort basis; response times are not guaranteed.
```

## AI 使用披露

```md
Parts of the documentation may be drafted with AI assistance. Commands, links, and technical claims are reviewed before release; users should still validate them in their own environment.
```


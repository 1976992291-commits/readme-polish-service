# [Project Name]

> [One-sentence English value proposition.]

[中文一句话说明：它为谁解决什么问题。]

## Highlights / 核心特点

- **[Feature 1]** — [Result, not implementation detail] / [中文结果说明]
- **[Feature 2]** — [Result] / [中文结果说明]
- **[Feature 3]** — [Result] / [中文结果说明]

## Quick Start / 快速开始

```bash
git clone [repository-url]
cd [directory]
[install-command]
[run-command]
```

Create `.env` from `.env.example` and add only the keys you need. Never commit secrets.

复制 `.env.example` 为 `.env`，仅填写必要密钥；不要把密钥提交到仓库。

## Example / 示例

```text
Input / 输入:  [realistic input]
Output / 输出: [representative output]
```

## Model & Data / 模型与数据

| Item / 项目 | Details / 说明 |
|---|---|
| Model / 模型 | [provider and model] |
| Data / 数据 | [what is sent, stored, or retained] |
| Cost / 成本 | [typical cost or limits] |
| Privacy / 隐私 | [privacy notes] |

## Roadmap / 路线图

- [ ] [Near-term milestone]
- [ ] [Next milestone]

## Contributing / 贡献

Issues and pull requests are welcome. Please describe the expected behavior and a minimal reproduction.

欢迎提交 Issue 和 PR；请说明期望行为并提供最小复现。

## License / 许可证

[License name] — see [LICENSE](LICENSE).


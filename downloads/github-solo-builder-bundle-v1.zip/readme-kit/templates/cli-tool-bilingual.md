# [CLI Name]

> [What the command automates] in one command. / 用一条命令完成[任务]。

## Install / 安装

```bash
[package-manager] install [package-name]
```

## Usage / 用法

```bash
[command] [input] --output [path]
```

```text
[sample output]
```

## Commands / 命令

| Command / 命令 | Description / 说明 |
|---|---|
| `[command] init` | [description] / [中文说明] |
| `[command] run` | [description] / [中文说明] |
| `[command] check` | [description] / [中文说明] |

## Configuration / 配置

| Option / 参数 | Default / 默认值 | Description / 说明 |
|---|---:|---|
| `--config` | `./config.yml` | [description] |
| `--verbose` | `false` | [description] |

## Troubleshooting / 常见问题

**`command not found`**：确认安装目录已加入 `PATH`。

**Permission denied / 权限不足**：不要直接使用管理员权限；先检查目标目录权限。

## License / 许可证

[License name] — see [LICENSE](LICENSE).


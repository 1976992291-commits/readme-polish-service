# [Library Name]

[Library Name] is a [language] library for [specific job]. / [Library Name] 是用于[具体任务]的 [语言] 库。

## Install / 安装

```bash
[install-command]
```

## Minimal Example / 最小示例

```[language]
[import statement]

[minimal working example]
```

## API

### `[function_or_class]`

```[language]
[signature]
```

- `[parameter]`: [meaning and accepted values]
- Returns / 返回： [return value]
- Raises / 异常： [error conditions]

## Compatibility / 兼容性

| Runtime / 环境 | Supported / 支持 |
|---|---|
| [version] | ✅ |
| [version] | ✅ |

## Development / 开发

```bash
[install-dev-command]
[test-command]
[lint-command]
```

## License / 许可证

[License name] — see [LICENSE](LICENSE).


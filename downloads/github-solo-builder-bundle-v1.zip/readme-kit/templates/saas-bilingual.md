# [Product Name]

> [Clear outcome for a specific audience.] / 帮助[目标用户]更快完成[结果]。

## Why / 为什么

[Two sentences describing the painful current workflow and your improvement.]

[用两句话描述用户当前的痛点，以及产品如何改善。]

## Features / 功能

- [Feature tied to a measurable benefit]
- [Feature tied to reduced time or cost]
- [Security/privacy feature]

## Demo / 演示

![Product screenshot]([screenshot-url])

- Live demo / 在线体验：[URL]
- Documentation / 文档：[URL]

## Self-host / 自托管

```bash
git clone [repository-url]
cd [directory]
cp .env.example .env
[start-command]
```

## Environment Variables / 环境变量

| Variable / 变量 | Required / 必填 | Description / 说明 |
|---|---|---|
| `[NAME]` | Yes | [description] |

## Security / 安全

Please report vulnerabilities privately via [security contact or SECURITY.md].

请通过[安全联系方式或 SECURITY.md]私下报告漏洞，不要公开披露未修复细节。

## License / 许可证

[License name] — see [LICENSE](LICENSE).

